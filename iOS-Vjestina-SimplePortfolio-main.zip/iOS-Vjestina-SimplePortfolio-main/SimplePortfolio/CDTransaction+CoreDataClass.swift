//
//  CDTransaction+CoreDataClass.swift
//  
//
//  Created by Ivan Vrkic on 27.06.2021..
//
//

import Foundation
import CoreData

@objc(CDTransaction)
public class CDTransaction: NSManagedObject {

}
