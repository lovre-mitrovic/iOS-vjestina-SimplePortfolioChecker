//
//  Status.swift
//  SimplePortfolio
//
//  Created by Lovre on 05/06/2021.
//

import Foundation
struct Status{
    var valueOfPortfolio: Float
    var changeInCurrency: Float
    var changeInPercentage: Float
}
