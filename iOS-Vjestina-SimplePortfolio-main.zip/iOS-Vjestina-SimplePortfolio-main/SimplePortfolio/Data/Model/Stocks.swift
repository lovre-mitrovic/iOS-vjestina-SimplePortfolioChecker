//
//  Stocks.swift
//  SimplePortfolio
//
//  Created by Ivan Vrkic on 25.06.2021..
//

import Foundation

struct Stocks: Codable {
    var bestMatches: [Stock]
}
