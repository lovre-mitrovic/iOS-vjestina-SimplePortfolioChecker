//
//  TransactionType.swift
//  SimplePortfolio
//
//  Created by Lovre on 11/06/2021.
//

import Foundation
@objc public enum TransactionType: Int16{
    case buy
    case sell
}
